<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko HP Jimli - Premium Smartphone Store</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <style>
      .navbar-custom {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
      }
      .hero-section {
        background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
        border-radius: 15px;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .card {
        transition: transform 0.3s ease-in-out;
        border: none;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .card:hover {
        transform: translateY(-5px);
      }
      .card-img-top {
        height: 200px;
        object-fit: cover;
      }
      .price-tag {
        color: #4f46e5;
        font-weight: bold;
        font-size: 1.2rem;
      }
      .footer {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
        color: white;
      }
      .search-form {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
      }
      .cart-btn {
        transition: all 0.3s ease;
      }
      .cart-btn:hover {
        transform: scale(1.05);
      }
    </style>
  </head>
  <body>
    <!-- Updated Navbar with Logout -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4">
      <div class="container">
        <a class="navbar-brand" href="#">
          <i class="fas fa-mobile-alt me-2"></i>
          Toko HP Jimli
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><i class="fas fa-home me-1"></i> Home</a>
            </li>
            <li class="nav-item">
              <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#loginModal">
                <i class="fas fa-sign-in-alt me-1"></i> Login
              </button>
            </li>
            <!-- Added Logout Button -->
            <li class="nav-item ms-2">
              <a href="<?= base_url() ?>auth/logout" class="btn btn-danger">
                <i class="fas fa-sign-out-alt me-1"></i> Logout
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url() ?>chart" class="nav-link cart-btn">
                <i class="fas fa-shopping-cart me-1"></i>
                Cart <span class="badge bg-warning">4</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="loginModalLabel">Login</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form>
              <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="email" class="form-control" id="email" placeholder="Enter your email" required />
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" placeholder="Enter your password" required />
              </div>
              <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <!-- Hero Section -->
      <div class="row hero-section mb-5">
        <div class="col-md-6 p-5">
          <h1 class="display-4 fw-bold mb-3">Welcome to Jimli Phone Store</h1>
          <p class="lead mb-4">Discover the latest smartphones from top brands at competitive prices.</p>
          <a href="#products" class="btn btn-primary btn-lg">
            <i class="fas fa-shopping-bag me-2"></i>Browse Products
          </a>
        </div>
        <div class="col-md-6 p-5">
          <div class="search-form">
            <h2 class="h4 mb-4"><i class="fas fa-search me-2"></i>Find Your Dream Phone</h2>
            <form action="">
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-mobile"></i></span>
                  <input type="text" class="form-control" placeholder="Brand (e.g., Samsung, iPhone)" />
                </div>
              </div>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text"><i class="fas fa-tag"></i></span>
                  <input type="text" class="form-control" placeholder="Model (e.g., S24, 13 Pro)" />
                </div>
              </div>
              <button class="btn btn-primary w-100">
                <i class="fas fa-search me-2"></i>Search
              </button>
            </form>
          </div>
        </div>
      </div>

      <!-- Products Section -->
      <h2 class="h3 mb-4" id="products">
        <i class="fas fa-fire me-2"></i>Featured Products
      </h2>
      <div class="row g-4 mb-5">
        <!-- Product Cards -->
        <div class="col-md-3">
          <div class="card h-100">
            <div class="position-absolute top-0 end-0 p-2">
              <span class="badge bg-danger">New</span>
            </div>
            <img src="images/hp1.jpeg" class="card-img-top" alt="Galaxy S24" />
            <div class="card-body">
              <h5 class="card-title">Samsung Galaxy S24</h5>
              <p class="price-tag mb-3">Rp 2.000.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Add to Cart
                </a>
                <button class="btn btn-outline-primary">
                  <i class="fas fa-heart"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-md-3">
          <div class="card h-100">
            <img src="images/hp2.jpeg" class="card-img-top" alt="iPhone 11" />
            <div class="card-body">
              <h5 class="card-title">iPhone 11</h5>
              <p class="price-tag mb-3">Rp 11.000.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Add to Cart
                </a>
                <button class="btn btn-outline-primary">
                  <i ```html
                  <i class="fas fa-heart"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card h-100">
            <div class="position-absolute top-0 end-0 p-2">
              <span class="badge bg-success">Sale</span>
            </div>
            <img src="images/hp3.jpeg" class="card-img-top" alt="Infinix" />
            <div class="card-body">
              <h5 class="card-title">Infinix Note</h5>
              <p class="price-tag mb-3">Rp 2.000.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Add to Cart
                </a>
                <button class="btn btn-outline-primary">
                  <i class="fas fa-heart"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3">
          <div class="card h-100">
            <img src="images/hp4.jpeg" class="card-img-top" alt="Redmi Note 11" />
            <div class="card-body">
              <h5 class="card-title">Redmi Note 11</h5>
              <p class="price-tag mb-3">Rp 2.700.000,-</p>
              <div class="d-flex justify-content-between align-items-center">
                <a href="<?= base_url() ?>chart" class="btn btn-primary">
                  <i class="fas fa-cart-plus me-2"></i>Add to Cart
                </a>
                <button class="btn btn-outline-primary">
                  <i class="fas fa-heart"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer py-4">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <h5><i class="fas fa-mobile-alt me-2"></i>Toko HP Jimli</h5>
            <p>Your trusted partner for premium smartphones in Jambi.</p>
          </div>
          <div class="col-md-4">
            <h5><i class="fas fa-map-marker-alt me-2"></i>Location</h5>
            <p>Jl. Main Street No. 123<br>Jambi, Indonesia</p>
          </div>
          <div class="col-md-4">
            <h5><i class="fas fa-envelope me-2"></i>Contact</h5>
            <p>Email: info@tokohpjimli.com<br>Phone: (021) 123-4567</p>
          </div>
        </div>
        <hr class="text-light">
        <div class="text-center">
          <p class="mb-0">© 2024 Toko HP Jimli. All Rights Reserved.</p>
        </div>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>